sub init()
    print "[HOME] initialized"
    m.topNavBar = m.top.findNode("topNavBar")
    m.patientsLabel = m.top.findNode("patientsLabel")
    m.eventsLabel = m.top.findNode("eventsLabel")
    m.medsLabel = m.top.findNode("medsLabel")
    m.verseLabel = m.top.findNode("verseLabel")
    m.drawingPoster = m.top.findNode("drawingPoster")
    m.navGrid = m.top.findNode("navGrid")
    m.errorDialog = m.top.findNode("errorDialog")
    
    m.topNavBar.title = "Welcome to FamilyCare TV"
    
    ' Populate Quick Nav Grid
    content = CreateObject("roSGNode", "ContentNode")
    
    AddItem(content, "Patients", "pkg:/images/icon_patients.png", "PatientsScene")
    AddItem(content, "Calendar", "pkg:/images/icon_calendar.png", "CalendarScene")
    AddItem(content, "Music", "pkg:/images/icon_music.png", "MusicScene")
    AddItem(content, "Kids", "pkg:/images/icon_kids.png", "KidsScene")
    AddItem(content, "Settings", "pkg:/images/icon_settings.png", "SettingsScreen")
    
    m.navGrid.content = content
    m.navGrid.observeField("itemSelected", "OnGridItemSelected")
    
    m.dashboardTask = m.top.findNode("dashboardTask")
    m.dashboardTask.observeField("response", "OnDashboardResponse")
    
    m.dashboardTask.request = {
        endpoint: "/roku/dashboard",
        method: "GET"
    }
    m.dashboardTask.control = "RUN"
    
    m.navGrid.setFocus(true)
end sub

sub AddItem(parent as Object, title as String, iconUri as String, targetScene as String)
    item = CreateObject("roSGNode", "ContentNode")
    item.title = title
    item.HDPosterUrl = iconUri
    item.description = targetScene
    parent.appendChild(item)
end sub

sub OnDashboardResponse(event as Object)
    response = event.getData()
    if response <> invalid and response.code = 200 and response.data <> invalid
        data = response.data
        
        pCount = 0
        if data.patientCount <> invalid
            pCount = data.patientCount
        else if data.patients <> invalid
            pCount = data.patients.count()
        end if
        m.patientsLabel.text = "Patients: " + pCount.toStr()

        eCount = 0
        if data.eventsCount <> invalid
            eCount = data.eventsCount
        else if data.reminders <> invalid
            eCount = data.reminders.count()
        end if
        m.eventsLabel.text = "Upcoming Events: " + eCount.toStr()

        mCount = 0
        if data.medsCount <> invalid
            mCount = data.medsCount
        end if
        m.medsLabel.text = "Medications: " + mCount.toStr()
        
        if data.verse <> invalid
            m.verseLabel.text = "Verse of the Day: " + Chr(10) + data.verse.text + " - " + data.verse.reference
        else if data.verseOfTheDay <> invalid and data.verseOfTheDay.verse <> invalid
            m.verseLabel.text = "Verse of the Day: " + Chr(10) + data.verseOfTheDay.verse + " - " + data.verseOfTheDay.reference
        else
            m.verseLabel.text = "Verse of the Day: " + Chr(10) + "For God so loved the world that he gave his one and only Son." + " - John 3:16"
        end if
        
        if data.drawingUrl <> invalid and data.drawingUrl <> ""
            m.drawingPoster.uri = data.drawingUrl
        end if
    else
        m.errorDialog.message = "Network error occurred. Please try again."
        m.errorDialog.show = true
    end if
end sub

sub OnGridItemSelected()
    selectedItem = m.navGrid.content.getChild(m.navGrid.itemSelected)
    if selectedItem <> invalid
        m.top.navigate = selectedItem.description
    end if
end sub

function onKeyEvent(key as String, press as Boolean) as Boolean
    handled = false
    if press
        if key = "up"
            handled = true
        else if key = "down"
            m.navGrid.setFocus(true)
            handled = true
        end if
    end if
    return handled
end function
